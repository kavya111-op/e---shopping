# e-shopping
E-ShopLite lets users browse a product catalog, search and filter products, add items to a shopping cart, and simulate checkout. Admin interface allows adding/editing products. Data stored in SQLite. The project demonstrates modular design (routes, models, templates), basic algorithms (search with substring matching, category filter, sorting.
# E-ShopLite

**Course:** Introduction to Problem Solving & Programming  
**Domain:** E-commerce  
**Complexity:** Intermediate

## Project Summary
E-ShopLite is a small e-commerce demonstration web application built with Flask and SQLite. It provides a product catalog with search/filter/sort/pagination, a session-based shopping cart, a simple admin panel for adding products, and a simulated checkout that updates stock.

## Features
- Product listing with pagination
- Search by name/description (substring match)
- Category filter and sorting by price
- Shopping cart (session-based)
- Simple checkout simulation (reduces stock)
- Admin page to add/delete products
- Sample data loader (`products_init.csv`)
- Unit tests (pytest)

## Repository Structure
Flask==2.3.3
click==8.1.7
itsdangerous==2.1.2
Jinja2==3.1.2
werkzeug==2.3.7
pytest==7.4.2
#!/usr/bin/env bash
export FLASK_APP=app.py
export FLASK_ENV=development
python3 -m flask run --host=127.0.0.1 --port=5000
# database.py - simple SQLite helper
import sqlite3
from flask import g

DB_PATH = "eshop.db"

def get_db():
    db = getattr(g, "_database", None)
    if db is None:
        db = g._database = sqlite3.connect(DB_PATH)
        db.row_factory = sqlite3.Row
    return db

def close_db(app):
    @app.teardown_appcontext
    def _close(exc):
        db = getattr(g, "_database", None)
        if db is not None:
            db.close()

def init_db():
    import sqlite3
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS products (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        description TEXT,
        price REAL NOT NULL,
        category TEXT,
        stock INTEGER DEFAULT 0,
        image TEXT
    )
    """)
    conn.commit()
    conn.close()
# models.py - product model helpers (SQLite, simple)
import sqlite3
from database import DB_PATH

def _connect():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn

def add_product(name, description, price, category, stock, image=None):
    conn = _connect()
    cur = conn.cursor()
    cur.execute(
        "INSERT INTO products (name, description, price, category, stock, image) VALUES (?, ?, ?, ?, ?, ?)",
        (name, description, float(price), category, int(stock), image)
    )
    conn.commit()
    pid = cur.lastrowid
    conn.close()
    return pid

def update_product(pid, **kwargs):
    conn = _connect()
    cur = conn.cursor()
    fields = []
    values = []
    for k, v in kwargs.items():
        fields.append(f"{k} = ?")
        values.append(v)
    values.append(pid)
    sql = f"UPDATE products SET {', '.join(fields)} WHERE id = ?"
    cur.execute(sql, values)
    conn.commit()
    conn.close()

def delete_product(pid):
    conn = _connect()
    cur = conn.cursor()
    cur.execute("DELETE FROM products WHERE id = ?", (pid,))
    conn.commit()
    conn.close()

def get_product(pid):
    conn = _connect()
    cur = conn.cursor()
    cur.execute("SELECT * FROM products WHERE id = ?", (pid,))
    row = cur.fetchone()
    conn.close()
    return dict(row) if row else None

def list_products(offset=0, limit=20, search=None, category=None, sort=None):
    conn = _connect()
    cur = conn.cursor()
    where = []
    params = []
    if search:
        where.append("(name LIKE ? OR description LIKE ?)")
        q = f"%{search}%"
        params.extend([q, q])
    if category:
        where.append("category = ?")
        params.append(category)
    where_clause = "WHERE " + " AND ".join(where) if where else ""
    order_clause = ""
    if sort == "price_asc":
        order_clause = "ORDER BY price ASC"
    elif sort == "price_desc":
        order_clause = "ORDER BY price DESC"
    else:
        order_clause = "ORDER BY id DESC"
    sql = f"SELECT * FROM products {where_clause} {order_clause} LIMIT ? OFFSET ?"
    params.extend([limit, offset])
    cur.execute(sql, params)
    rows = cur.fetchall()
    conn.close()
    return [dict(r) for r in rows]

def count_products(search=None, category=None):
    conn = _connect()
    cur = conn.cursor()
    where = []
    params = []
    if search:
        where.append("(name LIKE ? OR description LIKE ?)")
        q = f"%{search}%"
        params.extend([q, q])
    if category:
        where.append("category = ?")
        params.append(category)
    where_clause = "WHERE " + " AND ".join(where) if where else ""
    sql = f"SELECT COUNT(*) as cnt FROM products {where_clause}"
    cur.execute(sql, params)
    row = cur.fetchone()
    conn.close()
    return row[0] if row else 0
name,description,price,category,stock,image
"Wireless Mouse","Ergonomic wireless mouse",349.0,Electronics,25,
"USB-C Charger","Fast charger 65W",1299.0,Electronics,40,
"Yoga Mat","Non-slip yoga mat",799.0,Fitness,30,
"Notebook","100-page ruled notebook",49.0,Stationery,200,
"Ballpoint Pen","Smooth writing pen",19.0,Stationery,500,
"Coffee Mug","Ceramic 350ml mug",249.0,Home,60,
"T-shirt","Cotton tshirt - size M",399.0,Clothing,80,
"Bluetooth Speaker","Portable mini speaker",1499.0,Electronics,15,
"Organic Soap","Handmade organic soap",99.0,Personal Care,120,
"LED Desk Lamp","Adjustable desk lamp",899.0,Home,22,
# app.py - main Flask app
from flask import Flask, render_template, request, redirect, url_for, session, flash
import os
from database import init_db, close_db, DB_PATH
import models
import sqlite3
import csv

app = Flask(__name__)
app.secret_key = "change-this-to-a-random-secret"  # for sessions (in real deployments set env var)
close_db(app)

# initialize DB if missing
if not os.path.exists(DB_PATH):
    init_db()
    # optionally load sample data
    if os.path.exists("products_init.csv"):
        conn = sqlite3.connect(DB_PATH)
        cur = conn.cursor()
        with open("products_init.csv", newline='', encoding='utf-8') as f:
            reader = csv.DictReader(f)
            for r in reader:
                cur.execute(
                    "INSERT INTO products (name, description, price, category, stock, image) VALUES (?, ?, ?, ?, ?, ?)",
                    (r['name'], r['description'], float(r['price']), r['category'], int(r['stock']), None)
                )
        conn.commit()
        conn.close()

# Helper: cart in session
def get_cart():
    return session.setdefault("cart", {})

@app.route("/")
def index():
    # parameters
    page = max(int(request.args.get("page", 1)), 1)
    per_page = 6
    search = request.args.get("search", "").strip()
    category = request.args.get("category", "").strip() or None
    sort = request.args.get("sort", "")
    offset = (page - 1) * per_page
    products = models.list_products(offset=offset, limit=per_page, search=search or None, category=category, sort=sort)
    total = models.count_products(search=search or None, category=category)
    total_pages = max((total + per_page - 1) // per_page, 1)
    categories = ["Electronics","Fitness","Stationery","Home","Clothing","Personal Care"]
    return render_template("index.html", products=products, page=page, total_pages=total_pages, search=search, category=category, categories=categories, sort=sort)

@app.route("/product/<int:pid>")
def product(pid):
    p = models.get_product(pid)
    if not p:
        flash("Product not found.")
        return redirect(url_for("index"))
    return render_template("product.html", product=p)

@app.route("/add_to_cart/<int:pid>", methods=["POST"])
def add_to_cart(pid):
    qty = int(request.form.get("quantity", 1))
    p = models.get_product(pid)
    if not p:
        flash("Product not found.")
        return redirect(url_for("index"))
    if qty < 1:
        qty = 1
    cart = get_cart()
    cart_item = cart.get(str(pid), {"qty": 0, "name": p["name"], "price": p["price"]})
    cart_item["qty"] += qty
    cart[str(pid)] = cart_item
    session["cart"] = cart
    flash(f"Added {qty} × {p['name']} to cart.")
    return redirect(request.referrer or url_for("index"))

@app.route("/cart")
def cart():
    cart = get_cart()
    total = sum(item["qty"] * item["price"] for item in cart.values())
    return render_template("cart.html", cart=cart, total=total)

@app.route("/update_cart", methods=["POST"])
def update_cart():
    cart = get_cart()
    for pid, v in request.form.items():
        if pid.startswith("qty_"):
            real_pid = pid.split("_",1)[1]
            try:
                q = int(v)
            except:
                q = 0
            if q <= 0:
                cart.pop(real_pid, None)
            else:
                if real_pid in cart:
                    cart[real_pid]["qty"] = q
    session["cart"] = cart
    flash("Cart updated.")
    return redirect(url_for("cart"))

@app.route("/checkout", methods=["POST"])
def checkout():
    cart = get_cart()
    if not cart:
        flash("Cart is empty.")
        return redirect(url_for("index"))
    # simple simulated checkout: reduce stock
    for pid, item in cart.items():
        p = models.get_product(int(pid))
        if p:
            new_stock = max(0, p["stock"] - item["qty"])
            models.update_product(p["id"], stock=new_stock)
    session.pop("cart", None)
    return render_template("order_success.html")

# Admin interface (very basic, no auth for course demo)
@app.route("/admin", methods=["GET", "POST"])
def admin():
    if request.method == "POST":
        name = request.form.get("name")
        desc = request.form.get("description")
        price = request.form.get("price")
        category = request.form.get("category")
        stock = request.form.get("stock", 0)
        if not name or not price:
            flash("Name and price required.")
        else:
            models.add_product(name, desc, float(price), category, int(stock))
            flash("Product added.")
            return redirect(url_for("admin"))
    products = models.list_products(limit=100)
    return render_template("admin.html", products=products)

@app.route("/admin/delete/<int:pid>", methods=["POST"])
def admin_delete(pid):
    models.delete_product(pid)
    flash("Product deleted.")
    return redirect(url_for("admin"))

if __name__ == "__main__":
    app.run(debug=True)
<!doctype html>
<html>
<head>
  <meta charset="utf-8">
  <title>E-ShopLite</title>
  <link rel="stylesheet" href="{{ url_for('static', filename='styles.css') }}">
</head>
<body>
  <header class="header">
    <div class="container">
      <h1><a href="{{ url_for('index') }}">E-ShopLite</a></h1>
      <nav>
        <form action="{{ url_for('index') }}" method="get" class="search-form">
          <input type="text" name="search" placeholder="Search products..." value="{{ search|default('') }}">
          <button type="submit">Search</button>
        </form>
        <a class="btn" href="{{ url_for('cart') }}">Cart ({{ session.get('cart')|length or 0 }})</a>
        <a class="btn" href="{{ url_for('admin') }}">Admin</a>
      </nav>
    </div>
  </header>

  <main class="container">
    {% with messages = get_flashed_messages() %}
      {% if messages %}
        <ul class="messages">
          {% for m in messages %}
          <li>{{ m }}</li>
          {% endfor %}
        </ul>
      {% endif %}
    {% endwith %}

    {% block content %}{% endblock %}
  </main>

  <footer class="footer">
    <div class="container">
      <p>© E-ShopLite — Educational project</p>
    </div>
  </footer>
</body>
</html>
{% extends "base.html" %}
{% block content %}
<div class="filters">
  <form method="get" action="{{ url_for('index') }}">
    <label>Category:
      <select name="category">
        <option value="">All</option>
        {% for c in categories %}
          <option value="{{c}}" {% if c==category %}selected{% endif %}>{{c}}</option>
        {% endfor %}
      </select>
    </label>
    <label>Sort:
      <select name="sort">
        <option value="">Newest</option>
        <option value="price_asc" {% if sort=='price_asc' %}selected{% endif %}>Price: Low → High</option>
        <option value="price_desc" {% if sort=='price_desc' %}selected{% endif %}>Price: High → Low</option>
      </select>
    </label>
    <button type="submit">Apply</button>
  </form>
</div>

<div class="grid">
  {% for p in products %}
  <div class="card">
    <h3><a href="{{ url_for('product', pid=p['id']) }}">{{ p['name'] }}</a></h3>
    <p class="cat">{{ p['category'] }}</p>
    <p class="price">₹{{ "%.2f"|format(p['price']) }}</p>
    <form action="{{ url_for('add_to_cart', pid=p['id']) }}" method="post">
      <input type="number" name="quantity" value="1" min="1" max="{{ p['stock'] }}">
      <button type="submit">Add to cart</button>
    </form>
  </div>
  {% endfor %}
</div>

<div class="pagination">
  {% if page > 1 %}
    <a href="{{ url_for('index', page=page-1, search=search, category=category, sort=sort) }}">Prev</a>
  {% endif %}
  <span>Page {{ page }} / {{ total_pages }}</span>
  {% if page < total_pages %}
    <a href="{{ url_for('index', page=page+1, search=search, category=category, sort=sort) }}">Next</a>
  {% endif %}
</div>
{% endblock %}
{% extends "base.html" %}
{% block content %}
<div class="product-detail">
  <h2>{{ product['name'] }}</h2>
  <p class="cat">{{ product['category'] }}</p>
  <p class="price">₹{{ "%.2f"|format(product['price']) }}</p>
  <p>{{ product['description'] }}</p>
  <p>Stock: {{ product['stock'] }}</p>
  <form action="{{ url_for('add_to_cart', pid=product['id']) }}" method="post">
    <input type="number" name="quantity" value="1" min="1" max="{{ product['stock'] }}">
    <button type="submit">Add to cart</button>
  </form>
</div>
{% endblock %}
{% extends "base.html" %}
{% block content %}
<h2>Your Cart</h2>
<form method="post" action="{{ url_for('update_cart') }}">
  <table class="cart-table">
    <thead><tr><th>Product</th><th>Unit Price</th><th>Qty</th><th>Subtotal</th></tr></thead>
    <tbody>
      {% for pid, item in cart.items() %}
      <tr>
        <td>{{ item['name'] }}</td>
        <td>₹{{ "%.2f"|format(item['price']) }}</td>
        <td><input type="number" name="qty_{{ pid }}" value="{{ item['qty'] }}" min="0"></td>
        <td>₹{{ "%.2f"|format(item['price']*item['qty']) }}</td>
      </tr>
      {% endfor %}
    </tbody>
  </table>
  <p class="total">Total: ₹{{ "%.2f"|format(total) }}</p>
  <button type="submit">Update Cart</button>
</form>
<form method="post" action="{{ url_for('checkout') }}">
  <button type="submit">Checkout</button>
</form>
{% endblock %}
{% extends "base.html" %}
{% block content %}
<h2>Admin - Add Product</h2>
<form method="post">
  <label>Name: <input type="text" name="name" required></label><br>
  <label>Description: <textarea name="description"></textarea></label><br>
  <label>Price: <input type="number" step="0.01" name="price" required></label><br>
  <label>Category: <input type="text" name="category"></label><br>
  <label>Stock: <input type="number" name="stock" value="0"></label><br>
  <button type="submit">Add</button>
</form>

<h3>Existing Products</h3>
<ul>
  {% for p in products %}
    <li>{{ p['id'] }} - {{ p['name'] }} (₹{{ "%.2f"|format(p['price']) }}) 
      <form style="display:inline" method="post" action="{{ url_for('admin_delete', pid=p['id']) }}">
        <button type="submit">Delete</button>
      </form>
    </li>
  {% endfor %}
</ul>
{% endblock %}
{% extends "base.html" %}
{% block content %}
<h2>Order placed!</h2>
<p>Thank you. Your simulated order has been processed and stock updated.</p>
<p><a href="{{ url_for('index') }}">Continue Shopping</a></p>
{% endblock %}
body { font-family: Arial, sans-serif; margin:0; padding:0; background:#f6f7fb; color:#222; }
.container { width: 95%; max-width: 1000px; margin: 0 auto; padding: 20px; }
.header { background:#0a6ea7; color:white; padding: 10px 0; }
.header h1 { display:inline; margin:0; padding-left:10px; }
.header a { color:white; text-decoration:none; }
nav { float:right; padding-right:10px; }
nav .btn { color:white; background:rgba(255,255,255,0.12); padding:6px 10px; border-radius:4px; margin-left:6px; text-decoration:none; }
.search-form input { padding:6px; }
.grid { display:grid; grid-template-columns: repeat(auto-fit, minmax(220px,1fr)); gap:12px; margin-top:20px; }
.card { background:white; padding:12px; border-radius:8px; box-shadow:0 1px 4px rgba(0,0,0,0.06); }
.card h3 { margin:0 0 6px 0; font-size:1.1em; }
.card .price { color:#0a6ea7; font-weight:600; }
.footer { background:#222; color:white; padding:12px 0; margin-top:20px; text-align:center; }
.messages { list-style:none; padding:0; }
.product-detail { background:white; padding:12px; border-radius:8px; }
.cart-table { width:100%; border-collapse:collapse; }
.cart-table th, .cart-table td { border:1px solid #ddd; padding:8px; }
.filters { margin-top:10px; }
.pagination { margin-top:12px; }# tests/test_cart.py
from app import app
import pytest

@pytest.fixture
def client():
    app.config['TESTING'] = True
    with app.test_client() as c:
        yield c

def test_cart_flow(client):
    # get index
    resp = client.get('/')
    assert resp.status_code == 200
    # add product id 1 (assuming exists in sample data)
    resp = client.post('/add_to_cart/1', data={'quantity': '1'}, follow_redirects=True)
    assert resp.status_code == 200
    # view cart
    resp = client.get('/cart')
    assert resp.status_code == 200
    assert b'Your Cart' in resp.data

# tests/test_search.py
import models
from database import init_db
import os
import sqlite3

DB_TEST = "eshop.db"

def setup_module(module):
    # ensure DB exists & has some products
    init_db()
    # add a unique product
    try:
        models.add_product("UniqueTestProd", "searchable", 10.0, "Test", 10)
    except Exception:
        pass

def test_search_found():
    results = models.list_products(search="UniqueTestProd", limit=10)
    assert any("UniqueTestProd" in r['name'] for r in results)

def test_count_search():
    cnt = models.count_products(search="UniqueTestProd")
    assert cnt >= 1
# tests/test_models.py
import models# E-ShopLite
def test_add_and_get_delete():
    pid = models.add_product("TmpName", "TmpDesc", 10.5, "Temp", 3)
    p = models.get_product(pid)
    assert p['name'] == "TmpName"
    models.delete_product(pid)
    p2 = models.get_product(pid)
    assert p2 is None

## Setup & Run (local)
1. Clone the repo.
2. (Recommended) Create a virtual environment:
   ```bash
   python3 -m venv venv
   source venv/bin/activate
   pip install -r requirements.txt

